# config.py
import os

TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
MONITORS = ["BTCUSDT", "ETHUSDT", "SOLUSDT"]
