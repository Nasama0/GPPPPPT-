# Simple TradingView Telegram Bot 🧠📊

Цей бот надсилає ідеї з TradingView (BTC, ETH, SOL) у Telegram.

## 📦 Що вміє
- Парсить останні ідеї з TradingView
- Відправляє кнопку в Telegram
- Показує назву, автора, настрій і посилання

## 🚀 Запуск
1. Встанови залежності:
```
pip install -r requirements.txt
```
2. Додай змінну середовища TELEGRAM_TOKEN
3. Запусти:
```
python main.py
```

## ☁️ Хостинг
Працює на Render, Replit або локально.

З любов’ю до трейдингу 💸
